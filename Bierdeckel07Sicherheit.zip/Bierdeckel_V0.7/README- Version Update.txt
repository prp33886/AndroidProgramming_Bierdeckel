@author: Pascal Pribyl


Fortschritt:
Nav Headerdaten werden abgerufen (Name, Email)
Admincenter Fragment hinzugefügt
navigation IDs einheitlich refractort


ToDo:
Einheitliches farbschema
Funktion und design schulden hinzufügen
Home anzeige
Gallerie 
userinformationen User Bild in Storage speichern

Nav HeaderProfilPic 