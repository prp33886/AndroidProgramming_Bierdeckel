package org.wit.bierdeckel.models


data class debtModel(var schuldnerVorName: String? = null,
                     var schuldnerNachname: String? = null,
                     var schulden: Double?=null,
                     var schuldnerID: String?=null
                     ) : java.io.Serializable {




}
