package org.wit.bierdeckel.enums

enum class kategorien {
   PrivateBar,
   Huette,
   Partyraum,
   Wohnung,
   Default
}